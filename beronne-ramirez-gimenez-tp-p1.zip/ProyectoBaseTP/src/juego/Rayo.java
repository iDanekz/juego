package juego;

import java.awt.Image;

import entorno.Entorno;
import entorno.Herramientas;

public class Rayo {

	private double x;
	private double y;
	private double tamañoX;
	private double tamañoY;
	private String direccion;
	private double velocidad;
	private Image img;

	public Rayo(double x, double y, String direccion) {
		this.x = x;
		this.y = y;
		this.tamañoX = 10; // 197     
		this.tamañoY = 10; // 128
		this.velocidad = 4;
		this.img = Herramientas.cargarImagen("laserderecha.gif");
		this.direccion = direccion;
	}
	
	public void dibujar(Entorno entorno) {
		int laykaTamaño = 20;
		if (direccion == "U") {
			img = Herramientas.cargarImagen("laserarriba.gif");
			entorno.dibujarImagen(img, x, y - tamañoY / 0.17 - laykaTamaño, 0, 0.05);
			y -= velocidad;
		}
		if (direccion == "D") {
			img = Herramientas.cargarImagen("laserabajo.gif");
			entorno.dibujarImagen(img, x, y + tamañoY / 0.35, 0, 0.05);
			y += velocidad;
		}
		if (direccion == "L") {
			img = Herramientas.cargarImagen("laserizquierda.gif");
			entorno.dibujarImagen(img, x - tamañoX / 0.20, y - tamañoY / 0.5, 0, 0.05);
			x -= velocidad;
		}
		if (direccion == "R") {
			img = Herramientas.cargarImagen("laserderecha.gif");
			entorno.dibujarImagen(img, x + tamañoX / 0.20, y - tamañoY / 0.5, 0, 0.05);
			x += velocidad;
		}
	}

	public int impactoConPlanta(Planta[] plantas) {
		for (int i = 0; i < plantas.length; i++) {
			if (plantas[i] != null) {
				if (plantas[i].x() - plantas[i].tamaño() / 2 < x + tamañoX / 2
						&& x - tamañoX / 2 < plantas[i].x() + plantas[i].tamaño() / 2
						&& y + tamañoY / 2 > plantas[i].y() - plantas[i].tamaño() / 2
						&& y - tamañoY / 2 < plantas[i].y() + plantas[i].tamaño() / 2) {
					return i;
				}
			}
		}
		return -1;
	}

	public boolean salioDePantalla(Entorno e) {
		if (x < 0 - tamañoX || x > e.ancho() + tamañoX
				|| y > e.alto() + tamañoY || y < 0 - tamañoY) {
			return true;
		}
		return false;
	}

	public double x() {
		return x;
	}

	public double y() {
		return y;
	}

	public double getTamañoX() {
		return tamañoX;
	}

	public void setTamañoX(double tamañoX) {
		this.tamañoX = tamañoX;
	}

	public double getTamañoY() {
		return tamañoY;
	}

	public void setTamañoY(double tamañoY) {
		this.tamañoY = tamañoY;
	}
}