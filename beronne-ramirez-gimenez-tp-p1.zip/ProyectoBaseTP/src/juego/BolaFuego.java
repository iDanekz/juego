package juego;

import java.awt.Image;

import entorno.Entorno;
import entorno.Herramientas;

public class BolaFuego {

	private double x;
	private double y;
	private double tamañoX;
	private double tamañoY;
	private String direccion;
	private double velocidad;
	private Image img;

	public BolaFuego(double x, double y, String direccion) {
		this.x = x;
		this.y = y-10;
		this.tamañoX = 30; // 197
		this.tamañoY = 30; // 128
		this.velocidad = 0.7;
		this.img = Herramientas.cargarImagen("bolafuegoderecha.png");
		this.direccion = direccion;
	}

	public void dibujar(Entorno entorno) {
		int plantaTamaño = 10;
		
		if (direccion == "U") {
			img = Herramientas.cargarImagen("bolafuegoarriba.png");
			entorno.dibujarImagen(img, x, y - tamañoY / 2 - plantaTamaño, 0, 0.08);
			y -= velocidad;
		}
		if (direccion == "D") {
			img = Herramientas.cargarImagen("bolafuegoabajo.png");
			entorno.dibujarImagen(img, x, y + tamañoY / 2, 0, 0.08);
			y += velocidad;
		}
		if (direccion == "L") {
			img = Herramientas.cargarImagen("bolafuegoizquierda.png");
			entorno.dibujarImagen(img, x - tamañoX / 1, y - tamañoY / 2, 0, 0.08);
			x -= velocidad;
		}
		if (direccion == "R") {
			img = Herramientas.cargarImagen("bolafuegoderecha.png");
			entorno.dibujarImagen(img, x + tamañoX / 1, y - tamañoY / 2, 0, 0.08);
			x += velocidad;
		}
	}

	public int impactoConAuto(Auto[] autos) {
		for (int i = 0; i < autos.length; i++) {
			if (autos[i] != null) {
				if (autos[i].x() - autos[i].tamaño() / 2 < x + tamañoX / 2
						&& x - tamañoX / 2 < autos[i].x() + autos[i].tamaño() / 2
						&& y + tamañoY / 2 > autos[i].y() - autos[i].tamaño() / 2
						&& y - tamañoY / 2 < autos[i].y() + autos[i].tamaño() / 2) {
					return i;
				}
			}
		}
		return -1;
	}
	public boolean impactoConLayka(Layka layka) {
		if (layka != null) {
			if (layka.getX() - layka.getTamaño() / 2 < x + tamañoX / 2
					&& x - tamañoX / 2 < layka.getX() + layka.getTamaño() / 2
					&& y + tamañoY / 2 > layka.getY() - layka.getTamaño() / 2
					&& y - tamañoY / 2 < layka.getY() + layka.getTamaño() / 2) {
				return true;
			}
		}
		return false;
	}
	
	public boolean impactaConRayo(Rayo rayo) {
		if (rayo != null) {
			if (rayo.x() - rayo.getTamañoX() / 2 < x + tamañoX / 2
					&& x - tamañoX / 2 < rayo.x() + rayo.getTamañoX() / 2
					&& y + tamañoY / 2 > rayo.y() - rayo.getTamañoY() / 2
					&& y - tamañoY / 2 < rayo.y() + rayo.getTamañoY() / 2) {
				return true;
			}
		}
		return false;
	}
	
	public void mover(Entorno e) {
		if (direccion == "U") {
			y -= velocidad;
		}
		if (direccion == "D") {
			y += velocidad;
		}
		if (direccion == "R") {
			x += velocidad;
		}
		if (direccion == "L") {
			x -= velocidad;
		}
	}
	
	public boolean salioDePantalla(Entorno e) {
		if (x < 0 - tamañoX || x > e.ancho() + tamañoX
				|| y > e.alto() + tamañoY || y < 0 - tamañoY) {
			return true;
		}
		return false;
	}

	public double x() {
		return x;
	}

	public double y() {
		return y;
	}
}