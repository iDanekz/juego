package juego;

import java.awt.Color;
import java.awt.Image;
import entorno.Entorno;
import entorno.Herramientas;
import entorno.InterfaceJuego;
import javax.sound.sampled.Clip;

public class Juego extends InterfaceJuego {

	// El objeto Entorno que controla el tiempo y otros

	private Entorno entorno;

	// Generales del juego

	private int anchoPantalla;
	private int altoPantalla;
	private int tickFrecuencia;
	private Layka layka;
	private Rayo rayo;
	private Planta[] plantas;
	private Auto[] autos;
	private Planta plantaMuerto;
	private Auto autoMuerto;
	private int numeroPlantaMuerto;
	private int numeroAutoMuerto;
	private Camino camino;
	private int plantasMuertos;
	private Image imagenFondo;
	private Image imagenInterfazDatos;
	private Image imagenCargaRayo;
	private Image imagenPantallaFinalJuego;
	private Image imagenPantallaFinalJuegoGanaste;
	private Image imagenPantallaFinalJuegoPerdiste;
	private int segundosMuertePlanta;
	private int segundosMuerteAuto;
	private int segundosCargaRayo;
	private int tiempoDeRegeneracionDelPlanta;
	private int tiempoDeRegeneracionDelAuto;
	private int milisegundos;
	private int segundos;
	private int tiempoTotalDePartida;
	private int sumaTotal;
	private Clip audioFondo;
	private Clip audioPantallaPuntosGano;
	private Clip audioFinalPerdio;
	private String textoTiempoRestante;
	private String textoPlantasMuertos;
	private int puntajeMaximo;

	public Juego() {

		// Inicializa el objeto entorno

		anchoPantalla = 800;
		altoPantalla = 600;

		this.entorno = new Entorno(this, "Plantas Invasoras V1", anchoPantalla, altoPantalla);

		// Inicializar lo que haga falta para el juego

		// Definiendo Imagenes

		imagenPantallaFinalJuego = Herramientas.cargarImagen("pantallaFinalJuego1.png");
		imagenPantallaFinalJuegoGanaste = Herramientas.cargarImagen("GANASTE1.png");
		imagenPantallaFinalJuegoPerdiste = Herramientas.cargarImagen("PERDISTE 1.png");
		imagenCargaRayo = Herramientas.cargarImagen("barraRayo.gif");

		// Definiendo Audios que se pisan

		audioFondo = Herramientas.cargarSonido("audioFondo.wav");
		audioPantallaPuntosGano = Herramientas.cargarSonido("pantallaPuntosGano.wav");
		audioFinalPerdio = Herramientas.cargarSonido("gameover.wav");

		// Definiendo variables generales y objetos

		setteoDeVariables();

		// Inicia el juego!

		this.entorno.iniciar();
	}

	/**
	 * Durante el juego, el método tick() será ejecutado en cada instante y por lo
	 * tanto es el método más importante de esta clase. Aquí se debe actualizar el
	 * estado interno del juego para simular el paso del tiempo (ver el enunciado
	 * del TP para mayor detalle).
	 */

	public void tick() {

		/// Tiempo en sistema

		if (layka != null) {
			tickFrecuencia++;
			int contador = 1;
			if (tickFrecuencia >= 81 * contador) {
				milisegundos++;
				contador++;
			}
			if (milisegundos >= 81) {
				milisegundos = 0;
				segundos++;
			}
		}

		//////// Dibuja el escenario del juego ////////

		// Dibuja Escenario o superficie

		imagenFondo = Herramientas.cargarImagen("fondolayka.jpg");
		entorno.dibujarImagen(imagenFondo, entorno.ancho() / 2, entorno.alto() / 2, 0);

		// Dibuja Layka

		if (layka != null) {
			layka.dibujar(entorno);
		}

		if (layka != null) {
			if (!entorno.estaPresionada(entorno.TECLA_IZQUIERDA) && !entorno.estaPresionada(entorno.TECLA_DERECHA)
					&& !entorno.estaPresionada(entorno.TECLA_ARRIBA) && !entorno.estaPresionada(entorno.TECLA_ABAJO)) {
				layka.settearModoDetenido();
			}
		}

		// Dibuja Plantas

		for (Planta planta : plantas) {
			if (planta != null) {
				planta.dibujar(entorno);
			}
		}
		// Dibuja Autos

		for (Auto auto: autos) {
			if (auto != null) {
				auto.dibujar(entorno);
			}
		}

		// Dibuja Rayo
		if (rayo != null) {
			rayo.dibujar(entorno);
		}

		// Interfaz de usuario

		imagenInterfazDatos = Herramientas.cargarImagen("interfazDatos.png");
		entorno.dibujarImagen(imagenInterfazDatos, entorno.ancho() / 2, entorno.alto() / 2, 0);

		//// ESCRITURA SOBRE INTERFAZ USUARIO /////

		// Dibuja cantidad de plantas muertos

		textoPlantasMuertos = Integer.toString(plantasMuertos);
		entorno.cambiarFont("arial", 20, Color.black);
		entorno.escribirTexto(textoPlantasMuertos, entorno.ancho() - 732, entorno.alto() - 542);

		// Dibuja Carga del Rayo

		if (rayo == null && segundosCargaRayo <= segundos) {
			entorno.dibujarImagen(imagenCargaRayo, entorno.ancho() - 390, entorno.alto() - 30, 0);
		}

		// Dibuja Tiempo Restante y ejecuta la Finalizacion del juego

		if (tiempoTotalDePartida - segundos > 0) {
			textoTiempoRestante = Integer.toString(tiempoTotalDePartida - segundos);
			entorno.cambiarFont("arial", 30, Color.black);
			entorno.escribirTexto(textoTiempoRestante, entorno.ancho() - 223, entorno.alto() - 43);
			if (sumaTotal >= puntajeMaximo) {
				entorno.dibujarImagen(imagenPantallaFinalJuego, entorno.ancho() / 2, entorno.alto() / 2, 0);
				entorno.dibujarImagen(imagenPantallaFinalJuegoGanaste, entorno.ancho() / 2, entorno.alto() - 465, 0);
				audioPantallaPuntosGano.start();
				audioFondo.stop();
				audioFondo.setFramePosition(0);
				finalizarJuego();
			}
		} else {
			entorno.dibujarImagen(imagenPantallaFinalJuego, entorno.ancho() / 2, entorno.alto() / 2, 0);
			entorno.dibujarImagen(imagenPantallaFinalJuegoPerdiste, entorno.ancho() / 2, entorno.alto() - 465, 0);
			audioFinalPerdio.start();
			audioFondo.stop();
			audioFondo.setFramePosition(0);
			finalizarJuego();
		}

		////// CORE DEL JUEGO ///////

		// Movimientos Plantas

		for (Planta planta: plantas) {
			if (planta != null) {
				planta.mover(entorno);
			}
		}
		// Movimientos Autos

		for (Auto auto: autos) {
			if (auto != null) {
				auto.mover(entorno);
			}
		}

		// Muerte layka y Finalizacion del juego

		if (layka != null && layka.laImpactaron(plantas) || layka.laImpactaron(autos)) {
			//			Herramientas.cargarSonido("sakuraImpacto.wav").start();
			//			Herramientas.cargarSonido("sakuraMuerte.wav").start();
			tiempoTotalDePartida = segundos;
			layka = null;
		}

		// Muerte Plantas Rayo

		if (rayo != null && layka!= null) {
			numeroPlantaMuerto = rayo.impactoConPlanta(plantas);
			if (numeroPlantaMuerto != -1) {
				//				Herramientas.cargarSonido("ninjaMuerto.wav").start();
				segundosMuertePlanta = segundos;
				plantasMuertos++;
				sumaTotal+=5;
				rayo = null;
				plantaMuerto = plantas[numeroPlantaMuerto];
				plantas[numeroPlantaMuerto] = null;
			}
		}

		// Regeneracion Plantas

		if (tiempoDeRegeneracionDelPlanta + segundosMuertePlanta<= segundos && numeroPlantaMuerto != -1) {
			plantas[numeroPlantaMuerto] = new Planta(plantaMuerto.x(), plantaMuerto.y(), plantaMuerto.direccion());
			plantaMuerto = null;
			numeroPlantaMuerto = -1;
		}

		// Regeneracion Autos

		if (tiempoDeRegeneracionDelAuto + segundosMuerteAuto<= segundos && numeroAutoMuerto != -1) {
			autos[numeroAutoMuerto] = new Auto(autoMuerto.x(), autoMuerto.y(), autoMuerto.direccion());
			autoMuerto = null;
			numeroAutoMuerto = -1;
		}

		// Rayo esta fuera del Escenario

		if (rayo != null && rayo.salioDePantalla(entorno)) {
			rayo = null;
		}

		////// TECLAS DEL JUEGO //////

		if (entorno.estaPresionada('h') || entorno.estaPresionada(entorno.TECLA_IZQUIERDA) && layka != null) {
			layka.moverIzquierda(camino);
		}

		if (entorno.estaPresionada('l') || entorno.estaPresionada(entorno.TECLA_DERECHA) && layka != null) {
			layka.moverDerecha(camino);
		}

		if (entorno.estaPresionada('k') || entorno.estaPresionada(entorno.TECLA_ARRIBA) && layka != null) {
			layka.moverArriba(camino);
		}

		if (entorno.estaPresionada('j') || entorno.estaPresionada(entorno.TECLA_ABAJO) && layka != null) {
			layka.moverAbajo(camino);
		}

		if (entorno.estaPresionada(entorno.TECLA_ESPACIO) && segundosCargaRayo <= segundos && layka != null) {
			Herramientas.cargarSonido("laser4.wav").start();
			segundosCargaRayo = segundos + 0;
			rayo = layka.rayo();
		}
	}

	////// ADICIONALES ////////

	private void setteoDeVariables() {

		// Camino

		camino = new Camino();

		// Layka

		layka = new Layka();

		// Definiendo Variables de juego nuevo

		tickFrecuencia = 0;
		milisegundos = 0;
		segundos = 0;
		tiempoTotalDePartida = 60;
		plantasMuertos = 0; 
		segundosMuertePlanta= 0;
		segundosMuerteAuto=0;
		segundosCargaRayo = 0;
		tiempoDeRegeneracionDelPlanta= 2;
		tiempoDeRegeneracionDelAuto=5;
		plantaMuerto = null;
		autoMuerto=null;
		numeroPlantaMuerto = -1;
		numeroAutoMuerto = -1;
		sumaTotal = 0;
		puntajeMaximo = 160;

		// Creacion total de la planta,

		plantas = new Planta[7];// cantidad maxima de plantas en pantalla
		double posicionX = 0;
		double posicionY = 0;
		int planta = 0;
		int direccion = 0;
		String direccionPlanta = "";
		planta = numeroRandom(0, 4); // cantidad variable de plantas totales en partida
		for (int i = planta; i < plantas.length; i++) {
			direccion = numeroRandom(0, 2);
			if (i % 2 != 0) {
				if (direccion == 0) {
					direccionPlanta = "L";
				} else {
					direccionPlanta = "R";
				}
				posicionX = numeroRandom(0, entorno.alto() - 93);
				posicionY = camino.caminoDePatrullaPlantaSub(i);

				if (i == 3 && direccionPlanta == "R") { // calle de layka
					posicionX = numeroRandom(486, entorno.ancho());
				} else {
					posicionX = numeroRandom(0, 314);
				}
				plantas[i] = new Planta(posicionX, posicionY, direccionPlanta);
			} else {
				if (direccion == 0) {
					direccionPlanta = "U";
				} else {
					direccionPlanta= "D";
				}
				posicionX = camino.caminoDePatrullaPlantaSub(i);
				posicionY = numeroRandom(0, entorno.ancho());
				plantas[i] = new Planta(posicionX, posicionY, direccionPlanta);
			}
		}
		// Creacion total del auto

		autos = new Auto[4];// cantidad maxima de autos en pantalla
		double posicionX1 = 0;
		double posicionY1 = 0;
		int auto = 0;
		String direccionAuto= "";
		auto = numeroRandom(0, 2); // cantidad variable de auto totales en partida
		for (int i = auto; i < autos.length; i++) {
			direccion = numeroRandom(0, 2);
			if (i % 2 != 0) {
				if (direccion == 0) {
					direccionAuto= "L";
				} else {
					direccionAuto= "R";
				}
				posicionX1 = numeroRandom(0, entorno.alto() - 93);
				posicionY1 = camino.caminoDePatrullaAutoSub(i);

				if (i == 3 && direccionAuto== "R") { // calle de layka
					posicionX1 = numeroRandom(486, entorno.ancho());
				} else {
					posicionX1 = numeroRandom(0, 314);
				}
				autos[i] = new Auto(posicionX1, posicionY1, direccionAuto);
			} else {
				if (direccion == 0) {
					direccionAuto= "U";
				} else {
					direccionAuto= "D";
				}
				posicionX1 = camino.caminoDePatrullaAutoSub(i);
				posicionY1 = numeroRandom(0, entorno.ancho());
				autos[i] = new Auto(posicionX1, posicionY1, direccionAuto);
			}
		}
		audioFondo.start();
	}

	private void finalizarJuego() {
		layka = null;
		entorno.cambiarFont("sans", 38, Color.black);
		entorno.escribirTexto(textoPlantasMuertos, entorno.ancho() - 392, entorno.alto() - 332);
		String textoSumaTotal = Integer.toString(sumaTotal);
		entorno.cambiarFont("sans", 38, Color.black);
		entorno.escribirTexto(textoSumaTotal, entorno.ancho() - 392, entorno.alto() - 218);
		if (entorno.estaPresionada(entorno.TECLA_ENTER)) {
			audioFinalPerdio.stop();
			audioFinalPerdio.setFramePosition(0);
			audioPantallaPuntosGano.stop();
			audioPantallaPuntosGano.setFramePosition(0);
			setteoDeVariables(); // simula Juego juego = new Juego();
		}
	}

	private int numeroRandom(int min, int max) { // genera numero random el int max va como >>>> max + 1 <<<<
		return (int) ((Math.random() * (max - min)) + min);
	}

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Juego juego = new Juego();
	}

}
