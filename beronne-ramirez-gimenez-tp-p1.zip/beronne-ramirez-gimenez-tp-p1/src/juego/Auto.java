package juego;

import java.awt.Image;
import entorno.Entorno;
import entorno.Herramientas;

public class Auto {

	private double x;
	private double y;
	private double tamaño;
	private double velocidad;
	private String direccion;
	private Image img;

	public Auto(double x, double y, String direccion) {
		this.x = x;
		this.y = y;
		this.tamaño = 80;
		this.direccion = direccion;
		this.velocidad = 2.1;
		this.img = Herramientas.cargarImagen("AutoIzquierda.png");
	}

	public void dibujar(Entorno e) {
		if (direccion == "U") {
			img = Herramientas.cargarImagen("AutoArriba.png");
		}
		if (direccion == "D") {
			img = Herramientas.cargarImagen("AutoAbajo.png");
		}
		if (direccion == "R") {
			img = Herramientas.cargarImagen("AutoDerecha.png");
		}
		e.dibujarImagen(img, x - tamaño / 2, y - tamaño / 2, 0, 0.35);
	}

	public void mover(Entorno e) {
		if (direccion == "U") {
			y -= velocidad;
			if (0 >= y + tamaño / 2) {
				y = e.alto() - 93 + tamaño;
			}
		}
		if (direccion == "D") {
			y += velocidad;
			if (e.alto() - 93 <= y - tamaño / 2) {
				y = 0 - tamaño;
			}
		}
		if (direccion == "R") {
			x += velocidad;
			if (e.ancho() <= x - tamaño / 2) {
				x = 0 - tamaño;
			}
		}
		if (direccion == "L") {
			x -= velocidad;
			if (0 >= x + tamaño / 2) {
				x = e.ancho() + tamaño;
			}
		}
	}

	public double x() {
		return x;
	}

	public double y() {
		return y;
	}

	public double tamaño() {
		return tamaño;
	}

	public String direccion() {
		return direccion;
	}
}
