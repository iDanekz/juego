package juego;

import java.awt.Image;
import entorno.Entorno;
import entorno.Herramientas;

public class Layka {

	private double x;
	private double y;
	private double tamaño;
	private String direccion;
	private double velocidad;
	private Image img;
	private boolean noSeMueve;

	public Layka() {
		this.setX(396); // por defecto aparece en el medio en ambas coordenadas
		this.setY(271);
		this.setTamaño(50);
		this.velocidad = 2;
		this.img = Herramientas.cargarImagen("layka.png");
		this.direccion = "D";
		this.noSeMueve = true;
	}
	
	public void dibujar(Entorno e) {
		if (!noSeMueve) {
			if (direccion == "U") {
				img = Herramientas.cargarImagen("layka.png");
			}
			if (direccion == "D") {
				img = Herramientas.cargarImagen("layka.png");
			}
			if (direccion == "R") {
				img = Herramientas.cargarImagen("layka.png");
			}
			if (direccion == "L") {
				img = Herramientas.cargarImagen("layka.png");
			}
		} else {
			if (direccion == "U") {
				img = Herramientas.cargarImagen("layka.png");
			}
			if (direccion == "D") {
				img = Herramientas.cargarImagen("layka.png");
			}
			if (direccion == "R") {
				img = Herramientas.cargarImagen("layka.png");
			}
			if (direccion == "L") {
				img = Herramientas.cargarImagen("layka.png");
			}
		}
		e.dibujarImagen(img, getX(), getY() - getTamaño() / 2, 0, 0.07);
	}

	public void moverIzquierda(Camino camino) {
		if (camino.posicionValida(getX() - velocidad, getY(), getTamaño())) {
			direccion = "L";
			setX(getX() - velocidad);
			noSeMueve = false;
		}
	}

	public void moverDerecha(Camino camino) {
		if (camino.posicionValida(getX() + velocidad, getY(), getTamaño())) {
			direccion = "R";
			setX(getX() + velocidad);
			noSeMueve = false;
		}
	}

	public void moverArriba(Camino camino) {
		if (camino.posicionValida(getX(), getY() - velocidad, getTamaño())) {
			direccion = "U";
			setY(getY() - velocidad);
			noSeMueve = false;
		}
	}

	public void moverAbajo(Camino camino) {
		if (camino.posicionValida(getX(), getY() + velocidad, getTamaño())) {
			direccion = "D";
			setY(getY() + velocidad);
			noSeMueve = false;
		}
	}

	public boolean laImpactaron(Auto[] autos) {
		int areaAuto = 30;
		int areaLayka = 30;
		for (int i = 0; i < autos.length; i++) {
			if (autos[i] != null) {
				if (autos[i].x() - areaAuto / 2 < getX() + areaLayka / 2
						&& getX() - areaLayka / 2 < autos[i].x() + areaAuto / 2
						&& getY() + areaLayka / 2 > autos[i].y() - areaAuto / 2
						&& getY() - areaLayka / 2 < autos[i].y() + areaAuto / 2) {
					return true;
				}
			}
		}
		return false;
	}
	
	public boolean laImpactaron(Plantas[] planta) {
		int areaPlanta = 30;
		int areaLayka = 30;
		for (int i = 0; i < planta.length; i++) {
			if (planta[i] != null) {
				if (planta[i].x() - areaPlanta / 2 < getX() + areaLayka / 2
						&& getX() - areaLayka / 2 < planta[i].x() + areaPlanta / 2
						&& getY() + areaLayka / 2 > planta[i].y() - areaPlanta / 2
						&& getY() - areaLayka / 2 < planta[i].y() + areaPlanta / 2) {
					return true;
				}
			}
		}
		return false;
	}
	

	public Rayo rayo() {
		if (direccion == "U") {
			return new Rayo(getX(), getY() - getTamaño() / 2, direccion);
		}
		if (direccion == "D") {
			return new Rayo(getX(), getY() + getTamaño() / 2, direccion);
		}
		if (direccion == "L") {
			return new Rayo(getX() - getTamaño() / 2, getY(), direccion);
		}
		return new Rayo(getX() + getTamaño() / 2, getY(), direccion);
	}

	public void settearModoDetenido() {
		noSeMueve = true;
	}

	public double getTamaño() {
		return tamaño;
	}

	public void setTamaño(double tamaño) {
		this.tamaño = tamaño;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

}