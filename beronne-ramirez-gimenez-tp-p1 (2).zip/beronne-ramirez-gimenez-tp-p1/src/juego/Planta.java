package juego;

import java.awt.Image;
import entorno.Entorno;
import entorno.Herramientas;

public class Planta {

	private double x;
	private double y;
	private double tamaño;
	private double velocidad;
	private String direccion;
	private Image img;
	private BolaFuego bolafuego;
	private boolean bolaDestruida = false;
	private int tiempoRegeneracion = 200;

	public Planta(double x, double y, String direccion) {
		this.x = x;
		this.y = y;
		this.tamaño = 67;
		this.direccion = direccion;
		this.velocidad = 0.5;
		this.img = Herramientas.cargarImagen("plantaI.gif");
	}

	public void dibujar(Entorno e) {
		if (direccion == "U") {
			img = Herramientas.cargarImagen("plantaArriba.gif");
		}
		if (direccion == "D") {
			img = Herramientas.cargarImagen("plantaAbajo.gif");
		}
		if (direccion == "R") {
			img = Herramientas.cargarImagen("PlantaD.gif");
		}
		e.dibujarImagen(img, x, y - tamaño / 2, 0, 0.35);
	}
	
	public void disparar(Entorno e) {
		double distanciaAlBorde = calcularDistanciaAlBorde(e);
        if (distanciaAlBorde >= 200) {
            this.bolafuego = new BolaFuego(x, y, direccion);
            this.bolafuego.dibujar(e);
            System.out.println("ENTRA A DISPARAR EN PLANTA");
        }
	}

	public void mover(Entorno e) {
		if (direccion == "U") {
			y -= velocidad;
			if (0 >= y + tamaño / 2) {
				y = e.alto() - 93 + tamaño;
			}
		}
		if (direccion == "D") {
			y += velocidad;
			if (e.alto() - 93 <= y - tamaño / 2) {
				y = 0 - tamaño;
			}
		}
		if (direccion == "R") {
			x += velocidad;
			if (e.ancho() <= x - tamaño / 2) {
				x = 0 - tamaño;
			}
		}
		if (direccion == "L") {
			x -= velocidad;
			if (0 >= x + tamaño / 2) {
				x = e.ancho() + tamaño;
			}
		}
	}
	 private double calcularDistanciaAlBorde(Entorno e) {
	        double distancia = 0.0;

	        if (direccion.equals("U")) {
	            distancia = y;
	        } else if (direccion.equals("D")) {
	            distancia = e.alto() - y;
	        } else if (direccion.equals("L")) {
	            distancia = x;
	        } else if (direccion.equals("R")) {
	            distancia = e.ancho() - x;
	        }

	        return distancia;
	    }

	public double x() {
		return x;
	}

	public double y() {
		return y;
	}

	public double tamaño() {
		return tamaño;
	}

	public String direccion() {
		return direccion;
	}
	public BolaFuego getBolafuego() {
		return bolafuego;
	}
	public void setBolafuego(BolaFuego bolafuego) {
		this.bolafuego = bolafuego;
	}
	public boolean isBolaDestruida() {
		if(bolaDestruida) {
			tiempoRegeneracion--;
			if(tiempoRegeneracion == 0) {
				bolaDestruida = false;
				tiempoRegeneracion = 200;
			}
		}
		
		return bolaDestruida;
	}
	public void setBolaDestruida(boolean bolaDestruida) {
		this.bolaDestruida = bolaDestruida;
	}
}

