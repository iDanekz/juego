package juego;

import java.awt.Image;

import entorno.Entorno;
import entorno.Herramientas;

public class Rayo {

	private double x;
	private double y;
	private double tamañoX;
	private double tamañoY;
	private String direccion;
	private double velocidad;
	private Image img;

	public Rayo(double x, double y, String direccion) {
		this.x = x;
		this.y = y;
		this.tamañoX = 20; // 197
		this.tamañoY = 20; // 128
		this.velocidad = 15;
		this.img = Herramientas.cargarImagen("noemi-coute-laser.gif");
		this.direccion = direccion;
	}

	public void dibujar(Entorno entorno) {
		int laykaTamaño = 40;
		if (direccion == "U") {
			img = Herramientas.cargarImagen("rayoU.gif");
			entorno.dibujarImagen(img, x, y - tamañoY / 2 - laykaTamaño, 0, 0.2);
			y -= velocidad;
		}
		if (direccion == "D") {
			img = Herramientas.cargarImagen("noemi-coute-laser.gif");
			entorno.dibujarImagen(img, x, y + tamañoY / 2, 0, 0.2);
			y += velocidad;
		}
		if (direccion == "L") {
			img = Herramientas.cargarImagen("rayoL.gif");
			entorno.dibujarImagen(img, x - tamañoX / 2, y - tamañoY / 2, 0, 0.2);
			x -= velocidad;
		}
		if (direccion == "R") {
			img = Herramientas.cargarImagen("noemi-coute-laser.gif");
			entorno.dibujarImagen(img, x + tamañoX / 1, y - tamañoY / 2, 0, 0.1);
			x += velocidad;
		}
	}

	public int impactoConAuto(Auto[] autos) {
		for (int i = 0; i < autos.length; i++) {
			if (autos[i] != null) {
				if (autos[i].x() - autos[i].tamaño() / 2 < x + tamañoX / 2
						&& x - tamañoX / 2 < autos[i].x() + autos[i].tamaño() / 2
						&& y + tamañoY / 2 > autos[i].y() - autos[i].tamaño() / 2
						&& y - tamañoY / 2 < autos[i].y() + autos[i].tamaño() / 2) {
					return i;
				}
			}
		}
		return -1;
	}
	
	public int impactoConPlantas(Plantas[] planta) {
		for (int i = 0; i < planta.length; i++) {
			if (planta[i] != null) {
				if (planta[i].x() - planta[i].tamaño() / 2 < x + tamañoX / 2
						&& x - tamañoX / 2 < planta[i].x() + planta[i].tamaño() / 2
						&& y + tamañoY / 2 > planta[i].y() - planta[i].tamaño() / 2
						&& y - tamañoY / 2 < planta[i].y() + planta[i].tamaño() / 2) {
					return i;
				}
			}
		}
		return -1;
	}

	public boolean salioDePantalla(Entorno e) {
		if (x < 0 - tamañoX || x > e.ancho() + tamañoX
				|| y > e.alto() + tamañoY || y < 0 - tamañoY) {
			return true;
		}
		return false;
	}

	public double x() {
		return x;
	}

	public double y() {
		return y;
	}
}